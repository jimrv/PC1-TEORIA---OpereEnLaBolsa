using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using TEOPC1.Models;

namespace TEOPC1.Controllers
{
    public class OpereBolsaController : Controller
    {
        private readonly ILogger<OpereBolsaController> _logger;

        public OpereBolsaController(ILogger<OpereBolsaController> logger)
        {
            _logger = logger;
        }

        private readonly List<Instrumento> _instrumentos = new List<Instrumento>
    {
        new Instrumento { Id = 1, Nombre = "S&P 500", Precio = 500 },
        new Instrumento { Id = 2, Nombre = "Dow Jones", Precio = 300 },
        new Instrumento { Id = 3, Nombre = "Bonos US", Precio = 120 }
    };

        public IActionResult Index()
        {
            ViewBag.Instrumentos = _instrumentos;
            return View();
        }

        [HttpPost]
        public IActionResult Invertir(Operacion operacion, List<int> instrumentosIds)
        {
            operacion.InstrumentosSeleccionados = _instrumentos.Where(i => instrumentosIds.Contains(i.Id)).ToList();

            var resultado = CalcularResultado(operacion);
            return View(resultado);
        }

        private ResultadoOperacion CalcularResultado(Operacion operacion)
        {
            var resultado = new ResultadoOperacion
            {
                Operacion = operacion,
                DetallesInstrumentos = new List<DetalleInstrumento>()
            };

            decimal subtotal = 0;
            foreach (var instrumento in operacion.InstrumentosSeleccionados)
            {
                var igv = instrumento.Precio * 0.18m;
                var monto = instrumento.Precio + igv;
                subtotal += monto;

                resultado.DetallesInstrumentos.Add(new DetalleInstrumento
                {
                    Nombre = instrumento.Nombre,
                    IGV = igv,
                    Monto = monto
                });
            }

            resultado.Comision = operacion.MontoAbonar > 300 ? 3 : 1;
            resultado.TotalPagar = subtotal + resultado.Comision;

            return resultado;
        }
    }
}