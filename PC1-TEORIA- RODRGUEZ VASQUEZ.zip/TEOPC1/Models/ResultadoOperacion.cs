using System.Collections.Generic;
namespace TEOPC1.Models
{
    public class ResultadoOperacion
    {
        public required Operacion Operacion { get; set; }
        public required List<DetalleInstrumento> DetallesInstrumentos { get; set; }
        public decimal Comision { get; set; }
        public decimal TotalPagar { get; set; }
    }
}