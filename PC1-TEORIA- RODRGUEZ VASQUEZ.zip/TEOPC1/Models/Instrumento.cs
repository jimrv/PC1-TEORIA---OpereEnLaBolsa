namespace TEOPC1.Models
{
    public class Instrumento
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public decimal Precio { get; set; }
    }
}