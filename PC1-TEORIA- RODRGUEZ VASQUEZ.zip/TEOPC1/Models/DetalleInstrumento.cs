namespace TEOPC1.Models
{
    public class DetalleInstrumento
    {
        public string? Nombre { get; set; }
        public decimal IGV { get; set; }
        public decimal Monto { get; set; }
    }
}