using System;
using System.Collections.Generic;

namespace TEOPC1.Models
{
    public class Operacion
    {
        public string? NombreApellido { get; set; }
        public string? CorreoElectronico { get; set; }
        public DateTime FechaOperacion { get; set; }
        public required List<Instrumento> InstrumentosSeleccionados { get; set; }
        public decimal MontoAbonar { get; set; }
    }
}